var searchData=
[
  ['_7esinga',['~Singa',['../class_singa.html#a4b2f9063d9d97cbf41f05c3558b2b9a6',1,'Singa']]]
];
