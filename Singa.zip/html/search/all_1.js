var searchData=
[
  ['fight',['fight',['../class_singa.html#a78556ed2114916e5b00234ef931b0e58',1,'Singa']]]
];
