var searchData=
[
  ['karnivor',['Karnivor',['../class_karnivor.html',1,'']]],
  ['kuda',['Kuda',['../class_kuda.html',1,'']]]
];
