var searchData=
[
  ['herbivor',['Herbivor',['../class_herbivor.html',1,'']]],
  ['hewan',['Hewan',['../class_hewan.html',1,'']]]
];
