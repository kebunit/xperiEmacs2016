var searchData=
[
  ['serigala',['Serigala',['../class_serigala.html',1,'']]],
  ['setarahgerak',['SetArahGerak',['../class_singa.html#a9ac8600a62bc6f33a42bfc2cd4d5d426',1,'Singa']]],
  ['setposisi',['SetPosisi',['../class_singa.html#adfcf66d135f5dc72060400e74173aa76',1,'Singa']]],
  ['setusia',['SetUsia',['../class_singa.html#a65ea5d6280ff39f313b5829130b7bcf8',1,'Singa']]],
  ['singa',['Singa',['../class_singa.html',1,'Singa'],['../class_singa.html#a2b6bc8f6bd4293c487734b5663b598ce',1,'Singa::Singa()'],['../class_singa.html#ad7b8861fb589c68e6a88f7295dc05fc1',1,'Singa::Singa(int _Power, int _Usia, int _Posisi, int _ArahGerak, int _Id)']]]
];
