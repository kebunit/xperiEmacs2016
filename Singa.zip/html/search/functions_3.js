var searchData=
[
  ['move',['move',['../class_singa.html#ab4a3ab4c47f2635944e2ac4a58953377',1,'Singa']]]
];
