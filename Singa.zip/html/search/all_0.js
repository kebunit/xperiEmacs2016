var searchData=
[
  ['destruct',['destruct',['../class_singa.html#acdcf6232b3a5c17b85fddbac64d7f3f0',1,'Singa']]]
];
