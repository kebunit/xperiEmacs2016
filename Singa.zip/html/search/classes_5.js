var searchData=
[
  ['serigala',['Serigala',['../class_serigala.html',1,'']]],
  ['singa',['Singa',['../class_singa.html',1,'']]]
];
